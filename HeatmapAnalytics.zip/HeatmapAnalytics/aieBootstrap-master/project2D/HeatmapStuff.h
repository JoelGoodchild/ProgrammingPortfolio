#pragma once
#include "heatmap.h"

class HeatmapStuff
{
public:
	HeatmapStuff();
	~HeatmapStuff();

	void AddHeatmapPoint(heatmap_t* map, int posX, int posY);
	unsigned char* buildHeatmapPixels(heatmap_t* map, int wW, int wH);
};