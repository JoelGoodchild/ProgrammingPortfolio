#include "Application2D.h"
#include "Texture.h"
#include "Font.h"
#include "Input.h"

Application2D::Application2D() {}

Application2D::~Application2D() {}

bool Application2D::startup() 
{
	m_2dRenderer = new aie::Renderer2D();

	m_level = new aie::Texture("./textures/exampleLevel.png");

	m_font = new aie::Font("./font/consolas.ttf", 32);

	m_heatmap = heatmap_new(getWindowWidth(), getWindowHeight());

	m_heatmapManager = new HeatmapStuff();

	m_heatmapTexture = nullptr;

	m_cameraX = 0;
	m_cameraY = 0;
	m_timer = 0;

	showHM = false;

	return true;
}

void Application2D::shutdown() 
{
	delete m_heatmapManager;
	m_heatmapManager = NULL;
	heatmap_free(m_heatmap);
	delete m_font;
	m_font = NULL;
	delete m_level;
	m_level = NULL;
	delete m_2dRenderer;
	m_2dRenderer = NULL;
}

void Application2D::update(float deltaTime) 
{
	m_timer += deltaTime;

	// input example
	aie::Input* input = aie::Input::getInstance();

	if (input->isMouseButtonDown(0))
	{
		//Stores the pixel data for the heatmap to be drawn
		unsigned char* heatmapPixelData;

		//Adds the location of the mouse pointer to the heatmap data
		m_heatmapManager->AddHeatmapPoint(m_heatmap, input->getMouseX(), getWindowHeight() - input->getMouseY());

		//Retrieves the pixel data of the heatmap to be drawn
		heatmapPixelData = m_heatmapManager->buildHeatmapPixels(m_heatmap, getWindowWidth(), getWindowHeight());

		//Checks if there is currently a heatmap texture, and overwrites it if there is
		if (m_heatmapTexture) delete m_heatmapTexture;

		//Creates the new texture for the heatmap
		m_heatmapTexture = new aie::Texture(getWindowWidth(), getWindowHeight(), aie::Texture::RGBA, heatmapPixelData);

		//Deletes the pixel data, allowing the new points to be added in the future
		delete heatmapPixelData;
	}

	if (input->wasKeyPressed(aie::INPUT_KEY_F1))
	{
		if (showHM)
			showHM = false;
		else
			showHM = true;
	}

	// exit the application
	if (input->isKeyDown(aie::INPUT_KEY_ESCAPE))
		quit();
}

void Application2D::draw() 
{
	// wipe the screen to the background colour
	clearScreen();

	// set the camera position before we begin rendering
	m_2dRenderer->setCameraPos(m_cameraX, m_cameraY);

	// begin drawing sprites
	m_2dRenderer->begin();
	
	//draw the level
	m_2dRenderer->drawSprite(m_level, 0, 0, (float)getWindowWidth(), (float)getWindowHeight(), 0, 0, 0, 0);

	// output some text, uses the last used colour
	char fps[32];
	//sprintf_s(fps, 32, "FPS: %i", getFPS());

	if (m_heatmapTexture && showHM)
		m_2dRenderer->drawSprite(m_heatmapTexture, 0, 0, (float)getWindowWidth(), (float)getWindowHeight(), 0, 0, 0, 0);

	// done drawing sprites
	m_2dRenderer->end();
}

void Application2D::buildTextureFromHeightMap()
{
	//Allocate some memory to store the generated pixel data
	unsigned char* heatmapPixelData = new unsigned char[getWindowWidth() * getWindowHeight() * 4];

	//Have the heatmap library create the pixel data from the heatmap
	heatmap_render_default_to(m_heatmap, heatmapPixelData);

	//If we already have a heatmap texture, delete the old one
	if (m_heatmapTexture) delete m_heatmapTexture;

	//Create the heatmap texture using the pixel data
	m_heatmapTexture = new aie::Texture(getWindowWidth(), getWindowHeight(), aie::Texture::RGBA, heatmapPixelData);

	//And finally, delete the pixeldata as it is now stored in the texture
	delete heatmapPixelData;
}