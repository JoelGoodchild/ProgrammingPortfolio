#include "HeatmapStuff.h"

HeatmapStuff::HeatmapStuff()
{
}

HeatmapStuff::~HeatmapStuff()
{
}

void HeatmapStuff::AddHeatmapPoint(heatmap_t* map, int posX, int posY)
{
	heatmap_add_point(map, posX, posY);
}

unsigned char* HeatmapStuff::buildHeatmapPixels(heatmap_t* map, int wW, int wH)
{
	//Allocate some memory to store the generated pixel data
	unsigned char* heatmapPixelData = new unsigned char[wW *wH * 4];

	//Have the heatmap library create the pixel data from the heatmap
	heatmap_render_default_to(map, heatmapPixelData);

	return heatmapPixelData;
}
