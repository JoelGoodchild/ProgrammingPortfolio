#pragma once

#include "Application.h"
#include "Renderer2D.h"
#include "heatmap.h"
#include "HeatmapStuff.h"

class Application2D : public aie::Application 
{
public:

	Application2D();
	virtual ~Application2D();

	virtual bool startup();
	virtual void shutdown();

	virtual void update(float deltaTime);
	virtual void draw();

	void buildTextureFromHeightMap();

protected:

	aie::Renderer2D*	m_2dRenderer;
	aie::Texture*		m_level;
	aie::Font*			m_font;
	heatmap_t*			m_heatmap;
	aie::Texture*		m_heatmapTexture;
	HeatmapStuff*		m_heatmapManager;

	float m_cameraX, m_cameraY;
	float m_timer;
	bool showHM;
};