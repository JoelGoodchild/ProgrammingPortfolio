﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using XboxCtrlrInput;

public class ToolSelect : MonoBehaviour {
    public int toolnum = 0;
    
	// Use this for initialization
	void Start ()
    {
		
	}
	
	// Update is called once per frame
	void Update ()
    {
        switch (toolnum)
        {
            default:
                break;
            case 1:
                Plunger();
                break;
        }
    }
    private void OnTriggerEnter(Collider other)
    {
        if(XCI.GetButtonDown(XboxButton.RightBumper))
        {
            toolnum++;
            if(toolnum > 4)
            {
                toolnum = 0;
            }
        }

    }

    void Plunger()
    {
        if (XCI.GetButtonDown(XboxButton.RightBumper))
        {
        }
    }

    void Evaporator()
    {

    }

    void DuctTape()
    {

    }

    void Idle()
    {

    }
}
